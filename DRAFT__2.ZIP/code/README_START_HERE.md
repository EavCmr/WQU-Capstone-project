# Final Clean Package -- Start Here

This is the polished, presentable version: 3 classification models (no redundant
duplicates) plus a forecast-ablation case study, publication-quality figures, and a
notebook organized like a paper's results section rather than a debug log. It reads
as one story: a ratio-based classifier flags ENEO's distress onset -> a real
consumption forecast independently confirms the drift kept worsening -> a real
revenue-leakage proxy and real news reporting corroborate both.

## Files

- **`capstone_final.ipynb`** -- the notebook. Upload `capstone_data.zip` to Colab
  (Files sidebar), Run All. Every cell has a markdown explanation above it. Takes
  under two minutes to run.
- **`capstone_final.py`** -- the same analysis as a plain script (for running outside
  Colab).
- **`data/`** -- 4 clean CSVs + a data dictionary (`README_DATA.md`). Zip this folder
  (`capstone_data.zip`) to upload to Colab.
- **`figures/`** -- all 7 figures, pre-generated, ready to paste into the report:
  - `fig1a_roc_model_a.png` -- Model A's ROC curve
  - `fig1b_roc_a_vs_b.png` -- Model A vs Model B, fair comparison
  - `fig2_shap_summary.png` -- SHAP feature attribution
  - `fig3_thresholds.png` -- Model C's empirical thresholds vs. the real distribution
  - `fig4_kplc_validation.png` -- the headline KPLC validation result
  - `fig5_eneo_context.png` -- ENEO risk score + real revenue-leakage context
  - `fig6_eneo_forecast_divergence.png` -- ENEO forecast-ablation case study: actual
    vs. frozen SARIMA forecast, and forecast-error vs. revenue-leakage trend
- **`results_table.csv`**, **`transfer_results.csv`**, **`eneo_forecast_results_monthly.csv`**,
  **`eneo_forecast_results_annual.csv`** -- the numeric results behind every figure.
- **`RESULTS_SUMMARY.md`** -- a one-page, report-ready summary of every number,
  including the full ENEO timeline.

## What changed vs. the earlier exploratory package

The earlier `Capstone_Full_Pipeline_Package.zip` was the working/audit-trail version --
useful for showing the full process (including a data-leakage bug we found and fixed),
but too cluttered to present. This package keeps only the 3 classification models that
matter for the paper (Model A, Model B, Model C) plus SHAP and the KPLC/ENEO
validation -- everything else (GradientBoosting comparisons, the synthetic-panel
duplicate, the kitchen-sink/SHAP-selection detour) was exploratory QA, documented
separately, not part of the clean result.

## Section 8 -- forecast-ablation case study (new)

The paper's title promises a *forecast-ablation framework*; Models A-C alone use raw
historical values, not forecasts or forecast errors. Section 8 closes that gap:
freezes a SARIMA model on ENEO's real 2020-2022 monthly consumption, forecasts
forward without refitting, and shows the forecast error grows at a statistically
significant, quantified rate (the Consumption Forecast-Divergence Rate, CFDR) that
tracks the same 2023-2025 window where the real revenue-leakage proxy and real news
reporting also show ENEO's crisis deepening. See `RESULTS_SUMMARY.md` for the full
timeline and exact numbers.
