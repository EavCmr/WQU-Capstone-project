# Data Dictionary — Final Clean Package

Four files, all real, all traceable to a cited source. No synthetic or fabricated
values anywhere in this folder.

## `train_us_panel.csv` — Model A & B training data
87 real US utility company-years (SEC EDGAR), 9 companies, 6 real distress-years
(PG&E Corp x2 filings, GenOn Energy, Energy Future Holdings/Oncor).

| Column | Meaning |
|---|---|
| `company`, `ticker`, `fiscal_year` | Identifiers |
| `leverage` | total liabilities / total assets |
| `equity_ratio` | total equity / total assets |
| `debt_to_equity` | total liabilities / total equity |
| `net_margin` | net income / revenue |
| `delivery_gwh`, `delivery_yoy_change`, `delivery_volatility_3yr` | real electricity delivery volume + derived features, hand-extracted from each company's SEC 10-K filings (blank where not disclosed in a comparable format) |
| `distress_label` | 1 = real, documented bankruptcy/insolvency year; 0 = otherwise |

Model A uses the 4 ratio columns. Model B adds the 3 `delivery_*` columns.

## `transfer_africa_panel.csv` — held-out validation data
17 real utility-years, 5 Sub-Saharan African countries (ENEO/Cameroon, KPLC/Kenya,
ECG/Ghana, ZESCO/Zambia, TANESCO/Tanzania), from each utility's own published annual
reports. **Never used to train any model** — scored only, to test generalization.
Same 4 ratio definitions as above (`debt_to_equity` computed via the accounting
identity leverage/equity_ratio where both are real and equity_ratio ≠ 0).

## `eneo_consumption_context_annual.csv` — descriptive context only
Real ENEO national monthly consumption data (source: ENEO's internal distribution-
efficiency workbook, provided by a teammate's industry contact, employer-authorized),
aggregated to annual. `mean_prorating_gap_ratio` (the gap between prorated/billed and
actually-metered energy — a revenue-leakage proxy) rises steadily from 2.8% (2020) to
25.7% (2025), consistent with ENEO's independently-documented 2022–2026 debt crisis.
**Descriptive context for the ENEO case study only — not used as a model input**
(monthly granularity doesn't align rigorously with the annual financial-ratio panel).

## `eneo_monthly_consumption.csv` — forecast-ablation input (Section 8)
The underlying real monthly series behind the annual context file above: 70 months
(Jan 2020–Oct 2025), `ConsumptionProrated_Total` (billed/prorated estimate) and
`Consumption_Total` (actually metered) side by side. This is what the notebook fits
the SARIMA forecast to — a seasonal model frozen on 2020–2022 and forecast forward
without refitting, so that its growing forecast error becomes a leading-indicator
signal (the Consumption Forecast-Divergence Rate, CFDR) that is independent of the
ratio-based models and the revenue-leakage proxy above, tested against the same real
timeline. Same source as `eneo_consumption_context_annual.csv`.
