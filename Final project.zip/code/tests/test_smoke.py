"""
Smoke tests for the capstone data pipeline.

These are intentionally lightweight: they check that the real input data is
present and well-formed, that the core cross-validation routine returns a
sane result on a tiny synthetic case, and that the full analysis script runs
end-to-end without raising an exception. They are not a substitute for the
statistical robustness checks reported in the paper (permutation test,
bootstrap CIs, DeLong's test) -- those live in the paper's Results section --
this file only guards against the code silently breaking.

Run with:  pytest tests/test_smoke.py -v
"""
import os
import subprocess
import sys

import numpy as np
import pandas as pd
import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT, "data")


def test_required_data_files_exist():
    required = [
        "train_us_panel.csv",
        "transfer_africa_panel.csv",
        "eneo_consumption_context_annual.csv",
        "eneo_monthly_consumption.csv",
    ]
    for fname in required:
        path = os.path.join(DATA_DIR, fname)
        assert os.path.exists(path), f"missing required data file: {fname}"


def test_train_panel_shape_and_columns():
    df = pd.read_csv(os.path.join(DATA_DIR, "train_us_panel.csv"))
    expected_cols = {
        "company", "ticker", "fiscal_year", "leverage", "equity_ratio",
        "debt_to_equity", "net_margin", "distress_label",
        "delivery_gwh", "delivery_yoy_change", "delivery_volatility_3yr",
    }
    assert expected_cols.issubset(set(df.columns))
    assert len(df) == 87, f"expected 87 real US company-years, got {len(df)}"
    assert df["distress_label"].sum() == 6, "expected 6 real distress-years"
    assert df["company"].nunique() == 9, "expected 9 real companies"


def test_transfer_panel_shape():
    df = pd.read_csv(os.path.join(DATA_DIR, "transfer_africa_panel.csv"))
    assert len(df) == 17, f"expected 17 real transfer utility-years, got {len(df)}"
    assert df["country"].nunique() == 5


def test_loco_cv_returns_valid_auc_range():
    """Re-implements the minimal LOCO-CV contract used throughout the paper
    (same logic as capstone_final.py's loco_cv) on the real training panel,
    and checks the output is a valid probability array with in-range AUC."""
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import roc_auc_score

    df = pd.read_csv(os.path.join(DATA_DIR, "train_us_panel.csv"))
    features = ["leverage", "equity_ratio", "debt_to_equity", "net_margin"]
    X = df[features].fillna(df[features].median()).values
    y = df["distress_label"].values
    groups = df["company"].values

    preds = np.zeros(len(df))
    for g in np.unique(groups):
        tr, te = groups != g, groups == g
        model = LogisticRegression(max_iter=2000, class_weight="balanced")
        model.fit(X[tr], y[tr])
        preds[te] = model.predict_proba(X[te])[:, 1]

    assert preds.min() >= 0.0 and preds.max() <= 1.0
    auc = roc_auc_score(y, preds)
    assert 0.9 <= auc <= 1.0, f"expected Model A full-panel AUC near 0.979, got {auc:.3f}"


@pytest.mark.slow
def test_full_pipeline_runs_end_to_end():
    """Runs the actual analysis script top-to-bottom and checks it exits
    cleanly. This is the same script referenced in the paper and README;
    a non-zero exit code here means the paper's numbers are not currently
    reproducible from the checked-in code."""
    script = os.path.join(ROOT, "capstone_final.py")
    result = subprocess.run(
        [sys.executable, script], cwd=ROOT, capture_output=True, text=True, timeout=300
    )
    assert result.returncode == 0, (
        f"capstone_final.py exited with code {result.returncode}\n"
        f"stdout:\n{result.stdout[-2000:]}\nstderr:\n{result.stderr[-2000:]}"
    )
